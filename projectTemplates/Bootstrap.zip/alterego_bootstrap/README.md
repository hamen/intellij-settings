\# Android Bootstrap App

* Advanced Android Logger
* RxAndroid
* Retrofit
* Butterknife
* FragmentArgs
* Lombok
* Dagger2
* Parceler
* Gson
* JodaTime